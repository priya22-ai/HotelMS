<!-- Footer -->
<footer class="site-footer">
    <div class="footer-inner">
        <div class="footer-brand">
            <div class="brand-icon-sm"><i class="fa-solid fa-bowl-food"></i></div>
            <span>MealMate System</span>
        </div>
        <div class="footer-links">
            <a href="<?= $base_path ?? '' ?>index.php">Home</a>
            <a href="<?= $base_path ?? '' ?>index.php#about">About</a>
            <a href="<?= $base_path ?? '' ?>index.php#contact">Contact</a>
        </div>
        <div class="footer-copy">
            &copy; <?= date('Y') ?> MealMate. All rights reserved.
            <span class="footer-heart"><i class="fa fa-heart"></i></span>
        </div>
    </div>
</footer>

<script src="<?= $base_path ?? '' ?>assets/js/main.js"></script>
<?php if(isset($extra_js)) echo $extra_js; ?>
</body>
</html>