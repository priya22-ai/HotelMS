<?php
// =============================================
// Database Configuration
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // apnar MySQL username
define('DB_PASS', '');           // apnar MySQL password
define('DB_NAME', 'meal_management');

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper: Check Admin Login
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// Helper: Check User Login
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Helper: Redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Helper: Sanitize input
function clean($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Helper: Format currency
function formatCurrency($amount) {
    return '৳ ' . number_format($amount, 2);
}

// Helper: Get Setting
function getSetting($key) {
    $db = getDB();
    $key = $db->real_escape_string($key);
    $result = $db->query("SELECT setting_value FROM settings WHERE setting_key='$key' LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $db->close();
        return $row['setting_value'];
    }
    $db->close();
    return null;
}
?>