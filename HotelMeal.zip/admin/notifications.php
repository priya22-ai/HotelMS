<?php
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect('admin/login.php');
$page_title = 'Notifications';
$base_path = '../';

$db = getDB();
$today = date('Y-m-d');

// Today's stats for notifications
$total_users        = $db->query("SELECT COUNT(*) as c FROM users WHERE status='active'")->fetch_assoc()['c'];
$orders_today       = $db->query("SELECT COUNT(*) as c FROM meal_orders WHERE order_date='$today'")->fetch_assoc()['c'];
$breakfast_today    = $db->query("SELECT SUM(breakfast) as s FROM meal_orders WHERE order_date='$today'")->fetch_assoc()['s'] ?? 0;
$lunch_today        = $db->query("SELECT SUM(lunch) as s FROM meal_orders WHERE order_date='$today'")->fetch_assoc()['s'] ?? 0;
$dinner_today       = $db->query("SELECT SUM(dinner) as s FROM meal_orders WHERE order_date='$today'")->fetch_assoc()['s'] ?? 0;
$pending_payments   = $db->query("SELECT COUNT(*) as c FROM payments WHERE status='pending'")->fetch_assoc()['c'];
$pending_amount     = $db->query("SELECT COALESCE(SUM(amount),0) as s FROM payments WHERE status='pending'")->fetch_assoc()['s'];

// All notifications
$notifs = $db->query("SELECT n.*, u.name as user_name FROM notifications n LEFT JOIN users u ON n.user_id=u.id ORDER BY n.created_at DESC LIMIT 50");

// Handle send notification
$msg = $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notif'])) {
    $title   = clean($_POST['title'] ?? '');
    $message = clean($_POST['message'] ?? '');
    $target  = clean($_POST['target'] ?? 'all');
    $type    = clean($_POST['type'] ?? 'info');

    if (!$title || !$message) {
        $err = 'Title and message are required.';
    } else {
        if ($target === 'all') {
            $users_q = $db->query("SELECT id FROM users WHERE status='active'");
            while ($u = $users_q->fetch_assoc()) {
                $uid = (int)$u['id'];
                $te = $db->real_escape_string($title);
                $me = $db->real_escape_string($message);
                $db->query("INSERT INTO notifications (user_id,title,message,type) VALUES ($uid,'$te','$me','$type')");
            }
            $msg = 'Notification sent to all users!';
        } else {
            $uid = (int)$target;
            $te = $db->real_escape_string($title);
            $me = $db->real_escape_string($message);
            $db->query("INSERT INTO notifications (user_id,title,message,type) VALUES ($uid,'$te','$me','$type')");
            $msg = 'Notification sent!';
        }
        // Refresh
        $notifs = $db->query("SELECT n.*, u.name as user_name FROM notifications n LEFT JOIN users u ON n.user_id=u.id ORDER BY n.created_at DESC LIMIT 50");
    }
}

$users_list = $db->query("SELECT id, name FROM users WHERE status='active' ORDER BY name");
$db->close();
include '../includes/header.php';
?>

<div class="dashboard-layout">
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="sidebar-avatar"><i class="fa fa-shield-halved"></i></div>
            <div>
                <div class="sidebar-name"><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></div>
                <div style="font-size:11px;opacity:0.6;margin-top:2px;">Administrator</div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <a href="dashboard.php"><i class="fa fa-gauge"></i> Dashboard</a>
            <a href="menu.php"><i class="fa fa-utensils"></i> Menu</a>
            <a href="users.php"><i class="fa fa-users"></i> Users</a>
            <a href="reports.php"><i class="fa fa-chart-bar"></i> Reports</a>
            <a href="notifications.php" class="active"><i class="fa fa-bell"></i> Notifications</a>
            <a href="settings.php"><i class="fa fa-gear"></i> Settings</a>
            <a href="timings.php"><i class="fa fa-clock"></i> Meal Timings</a>
            <a href="logout.php" style="margin-top:auto;color:#e07070;"><i class="fa fa-right-from-bracket"></i> Logout</a>
        </nav>
    </aside>

    <main class="main-content">
        <div class="page-header">
            <h1><i class="fa fa-bell" style="color:var(--primary)"></i> Notifications</h1>
        </div>

        <!-- Today's Meal Summary Cards -->
        <div class="stat-cards">
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(200,96,42,0.1);color:var(--primary);"><i class="fa fa-users"></i></div>
                <div><span class="stat-num"><?= $orders_today ?></span><span class="stat-label">Ordered Today</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(212,165,71,0.15);color:var(--gold);"><i class="fa fa-sun"></i></div>
                <div><span class="stat-num"><?= $breakfast_today ?></span><span class="stat-label">Breakfast Orders</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(42,126,200,0.1);color:#2a7ec8;"><i class="fa fa-cloud-sun"></i></div>
                <div><span class="stat-num"><?= $lunch_today ?></span><span class="stat-label">Lunch Orders</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(46,46,80,0.1);color:#444;"><i class="fa fa-moon"></i></div>
                <div><span class="stat-num"><?= $dinner_today ?></span><span class="stat-label">Dinner Orders</span></div>
            </div>
        </div>

        <?php if ($pending_payments > 0): ?>
        <div class="alert" style="background:rgba(212,165,71,0.1);border:1px solid rgba(212,165,71,0.3);padding:14px 20px;border-radius:var(--radius-sm);margin-bottom:20px;display:flex;align-items:center;gap:12px;">
            <i class="fa fa-exclamation-triangle" style="color:var(--gold);font-size:18px;"></i>
            <span><strong><?= $pending_payments ?></strong> pending payments totaling <strong>৳<?= number_format($pending_amount,2) ?></strong> need attention.</span>
            <a href="reports.php" class="btn btn-sm btn-outline" style="margin-left:auto;">View Reports</a>
        </div>
        <?php endif; ?>

        <div class="grid-2">
            <!-- Send Notification -->
            <div class="card">
                <div class="card-header"><h3><i class="fa fa-paper-plane"></i> Send Notification</h3></div>
                <div class="card-body">
                    <?php if ($msg): ?><div class="alert alert-success"><i class="fa fa-check-circle"></i> <?= $msg ?></div><?php endif; ?>
                    <?php if ($err): ?><div class="alert alert-danger"><i class="fa fa-circle-xmark"></i> <?= $err ?></div><?php endif; ?>
                    <form method="POST">
                        <input type="hidden" name="send_notif" value="1">
                        <div class="form-group">
                            <label>Title *</label>
                            <input type="text" name="title" class="form-control" placeholder="Notification title" required>
                        </div>
                        <div class="form-group">
                            <label>Message *</label>
                            <textarea name="message" class="form-control" rows="3" placeholder="Notification message..." required style="resize:vertical;"></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Send To</label>
                                <select name="target" class="form-control">
                                    <option value="all">📢 All Users</option>
                                    <?php
                                    $users_list2 = getDB()->query("SELECT id, name FROM users WHERE status='active' ORDER BY name");
                                    while ($u = $users_list2->fetch_assoc()):
                                    ?>
                                    <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Type</label>
                                <select name="type" class="form-control">
                                    <option value="info">ℹ️ Info</option>
                                    <option value="meal">🍽️ Meal</option>
                                    <option value="success">✅ Success</option>
                                    <option value="warning">⚠️ Warning</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">
                            <i class="fa fa-paper-plane"></i> Send Notification
                        </button>
                    </form>
                </div>
            </div>

            <!-- Recent Notifications -->
            <div class="card">
                <div class="card-header"><h3><i class="fa fa-bell"></i> Recent Notifications</h3></div>
                <div class="card-body" style="max-height:450px;overflow-y:auto;">
                    <?php if (!$notifs || $notifs->num_rows === 0): ?>
                        <div class="empty-state"><i class="fa fa-bell-slash"></i><p>No notifications yet</p></div>
                    <?php else: ?>
                    <div class="notif-list">
                        <?php while ($n = $notifs->fetch_assoc()): ?>
                        <div class="notif-item <?= $n['type'] ?>">
                            <div class="notif-icon">
                                <i class="fa fa-<?= $n['type']==='meal'?'utensils':($n['type']==='success'?'check':($n['type']==='warning'?'exclamation':'info')) ?>"></i>
                            </div>
                            <div style="flex:1;">
                                <div class="notif-title"><?= htmlspecialchars($n['title']) ?></div>
                                <div class="notif-msg"><?= htmlspecialchars($n['message']) ?></div>
                                <div class="notif-time">
                                    <i class="fa fa-user" style="font-size:10px;"></i>
                                    <?= $n['user_name'] ? htmlspecialchars($n['user_name']) : 'All Users' ?>
                                    · <?= date('d M, h:i A', strtotime($n['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?>