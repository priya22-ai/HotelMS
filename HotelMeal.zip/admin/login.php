<?php
require_once '../includes/config.php';
$page_title = 'Admin Login';
$base_path = '../';

$error = '';
$success = '';
$show_register = isset($_GET['register']) && $_GET['register'] == '1';

// Check if admin already exists
$db = getDB();
$adminExists = $db->query("SELECT id FROM admins LIMIT 1")->num_rows > 0;
$db->close();

// Handle Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $name    = clean($_POST['name'] ?? '');
    $email   = clean($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $phone   = clean($_POST['phone'] ?? '');
    $address = clean($_POST['address'] ?? '');

    if (!$name || !$email || !$pass) {
        $error = 'Please fill all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $db = getDB();
        $emailCheck = $db->real_escape_string($email);
        $exists = $db->query("SELECT id FROM admins WHERE email='$emailCheck' LIMIT 1")->num_rows;
        if ($exists) {
            $error = 'An admin with this email already exists.';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $name_e = $db->real_escape_string($name);
            $phone_e = $db->real_escape_string($phone);
            $addr_e  = $db->real_escape_string($address);
            $db->query("INSERT INTO admins (name,email,password,phone,address) VALUES ('$name_e','$emailCheck','$hash','$phone_e','$addr_e')");
            $success = 'Admin registered! You can now login.';
            $show_register = false;
            $adminExists = true;
        }
        $db->close();
    }
}

// Handle Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = clean($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (!$email || !$pass) {
        $error = 'Please enter email and password.';
    } else {
        $db = getDB();
        $emailE = $db->real_escape_string($email);
        $result = $db->query("SELECT * FROM admins WHERE email='$emailE' LIMIT 1");
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            if (password_verify($pass, $admin['password'])) {
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email']= $admin['email'];
                redirect('../admin/dashboard.php');
            } else {
                $error = 'Incorrect password.';
            }
        } else {
            $error = 'No admin found with this email.';
        }
        $db->close();
    }
}

if (isAdminLoggedIn()) redirect('../admin/dashboard.php');

include '../includes/header.php';
?>

<div class="auth-page">
    <div class="auth-bg-img"></div>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <div class="brand-icon"><i class="fa-solid fa-bowl-food"></i></div>
                <h2><?= $show_register ? 'Admin Registration' : 'Admin Login' ?></h2>
                <p><?= $show_register ? 'Create your admin account' : 'Welcome back, Admin' ?></p>
            </div>

            <?php if ($error): ?><div class="alert alert-danger"><i class="fa fa-circle-xmark"></i><?= $error ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><i class="fa fa-check-circle"></i><?= $success ?></div><?php endif; ?>

            <?php if ($show_register || !$adminExists): ?>
            <!-- REGISTRATION FORM -->
            <form method="POST">
                <input type="hidden" name="action" value="register">
                <div class="form-row">
                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="Admin name" required>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" name="phone" class="form-control" placeholder="+880...">
                    </div>
                </div>
                <div class="form-group">
                    <label>Email Address *</label>
                    <input type="email" name="email" class="form-control" placeholder="admin@example.com" required>
                </div>
                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" class="form-control" placeholder="Your address">
                </div>
                <button type="submit" class="btn-submit"><i class="fa fa-user-plus"></i> Register Admin</button>
            </form>
            <?php if ($adminExists): ?>
            <div class="auth-switch">Already registered? <a href="login.php">Login here</a></div>
            <?php endif; ?>

            <?php else: ?>
            <!-- LOGIN FORM -->
            <form method="POST">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="admin@example.com" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Your password" required>
                </div>
                <button type="submit" class="btn-submit"><i class="fa fa-right-from-bracket"></i> Login as Admin</button>
            </form>
            <div class="auth-switch">
                First time? <a href="login.php?register=1">Register Admin Account</a>
            </div>
            <?php endif; ?>

            <div class="auth-switch" style="margin-top:12px;">
                <a href="../index.php" style="color:rgba(255,255,255,0.4);font-size:12px;"><i class="fa fa-arrow-left"></i> Back to Home</a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>